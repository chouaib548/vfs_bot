# 🤖 بوت مراقبة مواعيد VFS إيطاليا - الجزائر

## المراكز التي يراقبها البوت
- الجزائر العاصمة (Algiers)
- عنابة (Annaba)
- قسنطينة (Constantine)
- وهران (Oran)
- أدرار (Adrar)

---

## ⚙️ طريقة التشغيل

### 1. تثبيت Python
تحميل من: https://www.python.org/downloads/

### 2. تثبيت المكتبات
```bash
pip install -r requirements.txt
```

### 3. تشغيل البوت
```bash
python vfs_monitor.py
```

---

## 🖥️ تشغيل على سيرفر مجاني (Railway)

1. سجل في https://railway.app
2. ارفع الملفات
3. اضبط Start Command: `python vfs_monitor.py`
4. يعمل 24/7 مجاناً!

---

## 📝 ملاحظات
- البوت يفحص كل 60 ثانية
- يرسل إشعار فقط عند وجود مواعيد جديدة
- يتجنب الإشعارات المكررة
- يسجل كل العمليات في ملف `vfs_monitor.log`

---

## ✏️ تعديل الإعدادات
افتح `vfs_monitor.py` وعدّل:
- `CHECK_INTERVAL` = فترة الفحص بالثواني (افتراضي: 60)
- `VISA_TYPES` = أنواع الفيزا التي تبحث عنها
